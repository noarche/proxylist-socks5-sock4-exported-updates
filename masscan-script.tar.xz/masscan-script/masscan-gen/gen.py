#!/usr/bin/env python3

import argparse
import configparser
import re
import sys
from pathlib import Path

# =========================
# Colors
# =========================
RESET = "\033[0m"
GREEN = "\033[1;32m"
CYAN = "\033[1;36m"
RED = "\033[1;31m"
YELLOW = "\033[1;33m"

CONFIG_FILE = "config.ini"


# =========================
# Logging
# =========================
def log(level: str, color: str, message: str) -> None:
    print(f"{color}[{level}]{RESET} {message}")


def verbose(message: str, enabled: bool) -> None:
    if enabled:
        log("VERBOSE", YELLOW, message)


# =========================
# Config Loader
# =========================
def load_config() -> configparser.ConfigParser:
    config = configparser.ConfigParser()

    if not Path(CONFIG_FILE).exists():
        raise FileNotFoundError(
            f"Missing required config file: {CONFIG_FILE}"
        )

    config.read(CONFIG_FILE)

    return config


# =========================
# Validation
# =========================
def parse_range(value: str) -> tuple[int, int]:
    match = re.fullmatch(r"(\d{1,3})-(\d{1,3})", value.strip())

    if not match:
        raise ValueError(
            "Invalid range format. Example: 98-101"
        )

    start = int(match.group(1))
    end = int(match.group(2))

    if not 0 <= start <= 255:
        raise ValueError("Start range must be 0-255")

    if not 0 <= end <= 255:
        raise ValueError("End range must be 0-255")

    if start > end:
        raise ValueError(
            "Start range cannot be greater than end range"
        )

    return start, end


# =========================
# Command Generator
# =========================
def generate_commands(
    start: int,
    end: int,
    config: configparser.ConfigParser,
    verbose_enabled: bool
) -> list[str]:

    settings = config["masscan"]

    ports = settings.get("ports")
    rate = settings.get("rate")
    interface = settings.get("interface")
    output_dir = settings.get("output_dir")
    output_prefix = settings.get("output_prefix")
    output_suffix = settings.get("output_suffix")
    output_file = settings.get("output_file")

    commands = []

    for ip in range(start, end + 1):

        scan_output = (
            f"{output_dir}/"
            f"{output_prefix}{ip}"
            f"{output_suffix}"
        )

        cmd = (
            f"sudo masscan {ip}.0.0.0/6 "
            f"-p{ports} "
            f"--rate {rate} "
            f"--output-filename {scan_output} "
            f"--interface {interface}"
        )

        commands.append(cmd)

        verbose(
            f"Generated command for {ip}.0.0.0/6",
            verbose_enabled
        )

    Path(output_file).write_text(
        "\n".join(commands) + "\n"
    )

    return commands


# =========================
# Main
# =========================
def main() -> None:

    parser = argparse.ArgumentParser(
        description="Generate masscan commands from IP ranges."
    )

    parser.add_argument(
        "-v",
        "--verbose",
        action="store_true",
        help="Enable verbose output"
    )

    args = parser.parse_args()

    log("INFO", CYAN, "Masscan Range Generator")
    print()

    try:
        config = load_config()

        ip_range = input(
            f"{CYAN}[?]{RESET} Enter IP range (example 98-101): "
        ).strip()

        start, end = parse_range(ip_range)

        commands = generate_commands(
            start,
            end,
            config,
            args.verbose
        )

        output_file = config["masscan"].get(
            "output_file"
        )

        print()

        log(
            "OK",
            GREEN,
            f"Generated {len(commands)} commands"
        )

        log(
            "OK",
            GREEN,
            f"Saved to {output_file}"
        )

    except KeyboardInterrupt:
        print()
        log("ABORT", RED, "User interrupted execution")
        sys.exit(1)

    except Exception as exc:
        log("ERROR", RED, str(exc))
        sys.exit(1)


if __name__ == "__main__":
    main()
