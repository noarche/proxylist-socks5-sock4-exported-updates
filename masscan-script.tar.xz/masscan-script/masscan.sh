#!/usr/bin/env bash

set -euo pipefail

# =========================
# Config
# =========================
RATE="14000"
PORTS="1080"
INTERFACE="tun0"

OUTPUT_DIR="/home/jonathan/masscan-script/scanresults"
ALT_OUTPUT_DIR="/home/jonathan/ramdisk"

TARGETS=(
  "74.0.0.0/5"
  "174.0.0.0/5"
  "155.0.0.0/5"
  "120.0.0.0/5"
  "130.0.0.0/5"
  "160.0.0.0/5"
  "190.0.0.0/5"
  "180.0.0.0/5"
)

# =========================
# Colors
# =========================
RED='\033[1;31m'
GREEN='\033[1;32m'
YELLOW='\033[1;33m'
BLUE='\033[1;34m'
NC='\033[0m'

# =========================
# Help
# =========================
show_help() {
    cat << EOF
Usage: $(basename "$0") [-v] [-h]

Options:
  -v    Verbose output
  -h    Show this help message

Description:
  Runs sequential masscan scans against configured CIDR ranges.
  Prompts once for sudo password, then keeps sudo alive automatically.
EOF
}

VERBOSE=0

while getopts ":vh" opt; do
    case $opt in
        v) VERBOSE=1 ;;
        h)
            show_help
            exit 0
            ;;
        *)
            echo -e "${RED}[-] Invalid option${NC}"
            show_help
            exit 1
            ;;
    esac
done

# =========================
# Prompt for sudo once
# =========================
echo -e "${BLUE}[*] Authenticating sudo session...${NC}"
sudo -v

# Keep sudo alive in background
while true; do
    sudo -n true
    sleep 50
    kill -0 "$$" || exit
done 2>/dev/null &

SUDO_KEEPALIVE_PID=$!

cleanup() {
    kill "$SUDO_KEEPALIVE_PID" 2>/dev/null || true
}
trap cleanup EXIT

# =========================
# Create output dirs
# =========================
mkdir -p "$OUTPUT_DIR"
mkdir -p "$ALT_OUTPUT_DIR"

# =========================
# Run scans
# =========================
for target in "${TARGETS[@]}"; do

    base_ip="${target%%/*}"

    if [[ "$base_ip" == "102.0.0.0" ]]; then
        outfile="${ALT_OUTPUT_DIR}/results102-proxy.scan"
    else
        first_octet="${base_ip%%.*}"
        outfile="${OUTPUT_DIR}/results${first_octet}-proxy.scan"
    fi

    echo -e "${GREEN}[+] Scanning ${target}${NC}"

    if [[ "$VERBOSE" -eq 1 ]]; then
        echo -e "${YELLOW}    Output: ${outfile}${NC}"
    fi

    sudo masscan "$target" \
        -p"$PORTS" \
        --rate "$RATE" \
        --output-filename "$outfile" \
        --interface "$INTERFACE"

    echo -e "${GREEN}[✓] Completed ${target}${NC}"
done

echo -e "${BLUE}[*] All scans completed.${NC}"
