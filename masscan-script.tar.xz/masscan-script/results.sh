#!/usr/bin/env python3
"""
scan_parser.py

Parses .scan files from a hardcoded directory and extracts:
IP:PORT

Example input line:
<host endtime="1779567223"><address addr="103.57.49.122" addrtype="ipv4"/><ports><port protocol="tcp" portid="4153"><state state="open" reason="syn-ack" reason_ttl="241"/></port></ports></host>

Example output:
103.57.49.122:4153

Output file format:
{numberOfLines}x_uncheckedProxylist_{timestamp}.txt
"""

from pathlib import Path
from datetime import datetime
import argparse
import re
import sys

# ============================================================
# CONFIG
# ============================================================

SCAN_DIR = Path("/home/jonathan/masscan-script/scanresults/")  # <-- CHANGE THIS

# ============================================================
# REGEX
# ============================================================

IP_REGEX = re.compile(r'addr="([^"]+)"')
PORT_REGEX = re.compile(r'portid="(\d+)"')

# ============================================================
# COLORS
# ============================================================

class C:
    RED = "\033[91m"
    GREEN = "\033[92m"
    YELLOW = "\033[93m"
    BLUE = "\033[94m"
    CYAN = "\033[96m"
    RESET = "\033[0m"
    BOLD = "\033[1m"


# ============================================================
# FUNCTIONS
# ============================================================

def verbose_print(enabled: bool, message: str, color: str = C.RESET):
    if enabled:
        print(f"{color}{message}{C.RESET}")


def extract_ip_port(line: str):
    """
    Extracts IP and port from a line.

    Returns:
        str | None
    """
    ip_match = IP_REGEX.search(line)
    port_match = PORT_REGEX.search(line)

    if not ip_match or not port_match:
        return None

    ip = ip_match.group(1)
    port = port_match.group(1)

    return f"{ip}:{port}"


def parse_scan_file(file_path: Path, results: set, verbose: bool):
    """
    Parses a single .scan file.
    """
    verbose_print(verbose, f"[+] Parsing: {file_path.name}", C.CYAN)

    try:
        with file_path.open("r", encoding="utf-8", errors="ignore") as f:
            for line in f:
                entry = extract_ip_port(line)
                if entry:
                    results.add(entry)

    except Exception as e:
        print(f"{C.RED}[!] Failed reading {file_path}: {e}{C.RESET}")


def find_scan_files(directory: Path):
    """
    Finds all .scan files recursively.
    """
    return list(directory.rglob("*.scan"))


def save_results(results: set):
    """
    Saves deduplicated results to output file.
    """
    sorted_results = sorted(results)

    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    filename = f"{len(sorted_results)}x_uncheckedProxylist_{timestamp}.txt"

    output_path = Path.cwd() / filename

    with output_path.open("w", encoding="utf-8") as f:
        f.write("\n".join(sorted_results))

    return output_path


# ============================================================
# MAIN
# ============================================================

def main():
    parser = argparse.ArgumentParser(
        description="Parse .scan files and extract IP:PORT pairs."
    )

    parser.add_argument(
        "-v",
        "--verbose",
        action="store_true",
        help="Enable verbose output"
    )

    args = parser.parse_args()

    if not SCAN_DIR.exists():
        print(
            f"{C.RED}[!] Directory does not exist:{C.RESET} {SCAN_DIR}"
        )
        sys.exit(1)

    print(f"{C.BLUE}{C.BOLD}[*] Searching for .scan files...{C.RESET}")

    scan_files = find_scan_files(SCAN_DIR)

    if not scan_files:
        print(f"{C.YELLOW}[!] No .scan files found.{C.RESET}")
        sys.exit(0)

    print(
        f"{C.GREEN}[+] Found {len(scan_files)} .scan files{C.RESET}"
    )

    results = set()

    for scan_file in scan_files:
        parse_scan_file(scan_file, results, args.verbose)

    if not results:
        print(f"{C.YELLOW}[!] No valid entries extracted.{C.RESET}")
        sys.exit(0)

    output_file = save_results(results)

    print(
        f"{C.GREEN}{C.BOLD}[+] Saved {len(results)} unique entries -> "
        f"{output_file.name}{C.RESET}"
    )


if __name__ == "__main__":
    main()
