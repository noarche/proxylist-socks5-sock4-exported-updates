package main

import (
	"bytes"
	"encoding/json"
	"flag"
	"fmt"
	"io/ioutil"
	"net"
	"net/http"
	"os"

	"strings"
	"sync"
	"time"

	"golang.org/x/net/proxy"
)

type ProxyDB struct {
	Known map[string]bool `json:"known"`
}

var (
	threads     int
	timeout     int
	proxyDBFile = "proxiesdb.json"
	resultDir   = "results"
	checkURL    = "https://example.com"
	titleMatch  = "<title>Example Domain</title>"
)

func color(c string, s string) string {
	colors := map[string]string{
		"red":    "\033[31;1m",
		"green":  "\033[32;1m",
		"yellow": "\033[33;1m",
		"blue":   "\033[34;1m",
		"reset":  "\033[0m",
	}
	return colors[c] + s + colors["reset"]
}

func loadProxyDB() ProxyDB {
	db := ProxyDB{Known: make(map[string]bool)}
	data, err := ioutil.ReadFile(proxyDBFile)
	if err == nil {
		_ = json.Unmarshal(data, &db)
	}
	return db
}

func saveProxyDB(db ProxyDB) {
	data, _ := json.MarshalIndent(db, "", "  ")
	_ = ioutil.WriteFile(proxyDBFile, data, 0644)
}

func fetchProxies(links []string, db ProxyDB) []string {
	proxySet := make(map[string]bool)
	for _, link := range links {
		resp, err := http.Get(link)
		if err != nil {
			fmt.Printf("Failed to fetch %s: %v\n", link, err)
			continue
		}
		body, _ := ioutil.ReadAll(resp.Body)
		resp.Body.Close()
		lines := strings.Split(string(body), "\n")
		for _, line := range lines {
			line = strings.TrimSpace(line)
			if line != "" && !db.Known[line] {
				proxySet[line] = true
			}
		}
	}
	var deduped []string
	for p := range proxySet {
		deduped = append(deduped, p)
	}
	return deduped
}

func checkProxy(proxyAddr string, network string, timeout time.Duration) bool {
	dialer, err := proxy.SOCKS5(network, proxyAddr, nil, &net.Dialer{Timeout: timeout})
	if err != nil {
		return false
	}
	client := &http.Client{
		Transport: &http.Transport{Dial: dialer.Dial},
		Timeout:   timeout,
	}
	resp, err := client.Get(checkURL)
	if err != nil {
		return false
	}
	body, _ := ioutil.ReadAll(resp.Body)
	resp.Body.Close()
	return bytes.Contains(body, []byte(titleMatch))
}

func writeResults(proxies []string, protocol string) {
	if len(proxies) == 0 {
		return
	}
	os.MkdirAll(resultDir, 0755)
	timestamp := time.Now().Format("20060102_150405")
	filename := fmt.Sprintf("%s/%dx_%s_%s.txt", resultDir, len(proxies), protocol, timestamp)
	ioutil.WriteFile(filename, []byte(strings.Join(proxies, "\n")), 0644)
	fmt.Println(color("green", fmt.Sprintf("Saved %d %s proxies to %s", len(proxies), protocol, filename)))
}

func printProgressBar(current, total int) {
	percent := float64(current) / float64(total) * 100
	barLen := 40
	filledLen := int(float64(barLen) * percent / 100)
	bar := strings.Repeat("█", filledLen) + strings.Repeat("-", barLen-filledLen)
	fmt.Printf("\r[%s] %.1f%% (%d/%d)", bar, percent, current, total)
	if current == total {
		fmt.Println()
	}
}

func main() {
	flag.IntVar(&threads, "t", 10, "Number of threads")
	flag.IntVar(&timeout, "d", 10000, "Timeout in milliseconds")
	flag.Parse()

	timeoutDuration := time.Duration(timeout) * time.Millisecond
	linkFile := "proxylist-links.dat"
	data, err := ioutil.ReadFile(linkFile)
	if err != nil {
		fmt.Println(color("red", "Failed to read proxylist-links.dat"))
		return
	}
	links := strings.Split(string(data), "\n")
	db := loadProxyDB()

	newProxies := fetchProxies(links, db)
	fmt.Printf("%d new proxies found\n", len(newProxies))

	var socks4Results, socks5Results []string
	sem := make(chan struct{}, threads)
	var wg sync.WaitGroup
	var mux sync.Mutex

	numberChecked := 0
	totalToCheck := len(newProxies)

	for _, p := range newProxies {
		wg.Add(1)
		sem <- struct{}{}
		go func(proxyAddr string) {
			defer wg.Done()
			defer func() { <-sem }()

			if checkProxy(proxyAddr, "tcp", timeoutDuration) {
				mux.Lock()
				socks5Results = append(socks5Results, proxyAddr)
				db.Known[proxyAddr] = true
				mux.Unlock()
				fmt.Printf("[SOCKS5] %s\n", proxyAddr)
			} else if checkProxy(proxyAddr, "tcp4", timeoutDuration) {
				mux.Lock()
				socks4Results = append(socks4Results, proxyAddr)
				db.Known[proxyAddr] = true
				mux.Unlock()
				fmt.Printf("[SOCKS4] %s\n", proxyAddr)
			} else {
				mux.Lock()
				db.Known[proxyAddr] = true
				mux.Unlock()
			}

			mux.Lock()
			numberChecked++
			printProgressBar(numberChecked, totalToCheck)
			mux.Unlock()
		}(p)
	}
	wg.Wait()

	saveProxyDB(db)
	writeResults(socks4Results, "SOCKS4")
	writeResults(socks5Results, "SOCKS5")
}
